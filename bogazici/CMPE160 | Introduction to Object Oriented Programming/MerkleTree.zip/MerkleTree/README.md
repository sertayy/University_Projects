# Merkle Tree Implementation Used in Torrent
An implementation (in Java) of a Merkle tree that checks the validity of the root hash of the file that is downloaded from a URL, showing the file (picture) if it’s valid, fixing the wrong chunk of the data by downloading the right chunk from given server and then shows it if it’s invalid.
