package project;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Set;
import java.util.Stack;

public class MerkleTree {
	
	private String path;
	private Node root;
	
	public MerkleTree(String path) throws NoSuchAlgorithmException, IOException {
		this.path = path;
		root = TreeCreator(path);
	}
	
	public Node TreeCreator(String path) throws NoSuchAlgorithmException, IOException {
		Queue<Node> leaves = new LinkedList<Node>();
		Queue<Node> parentLeaves = new LinkedList<Node>();

		File file = new File(path);
		Scanner scan = new Scanner(file);
		while(scan.hasNext()) {
			Node leave = new Node(new File(scan.nextLine()));
			leaves.add(leave);		
		}
		Node first;
		Node second;
		
		while(leaves.size() != 1) {
		if(leaves.size()%2 == 0) {
			while(!leaves.isEmpty()) {
				first = leaves.remove();
				second = leaves.remove();
				Node parentLeave = new Node(first,second);
				parentLeaves.add(parentLeave);
			}
			leaves.addAll(parentLeaves);
			parentLeaves.clear();
			
		} else {
			while(!leaves.isEmpty() && leaves.size()!=1) {
				first = leaves.remove();
				second = leaves.remove();
				Node parentLeave = new Node(first,second);
				parentLeaves.add(parentLeave);
			}
				first = leaves.remove();
				Node parentLeave = new Node(first,null);
				parentLeaves.add(parentLeave);
				leaves.addAll(parentLeaves);
				parentLeaves.clear();
			}
		}
		return leaves.peek();
	}
	
	public boolean checkAuthenticity(String string) throws FileNotFoundException {
		File file = new File(string);
		Scanner scan = new Scanner(file);
		if(scan.next().equals(root.getData())){
			return true;
		} else return false;
	}

	public Node getRoot() {
		return root;
	}

	public ArrayList<Stack<String>> findCorruptChunks(String string) throws FileNotFoundException {
	
		ArrayList<Stack<String>> corruptedPaths = new ArrayList<Stack<String>>();
		File file = new File(string);
		Scanner scan = new Scanner(file);
		Set<String> correctHashes = new HashSet<String>();
		while(scan.hasNext()) {
			correctHashes.add(scan.next());
		}
		if(correctHashes.contains(root.getData())) {
			return corruptedPaths;
		}
		Stack<String> corruptedHashes = new Stack<String>();
		corruptedHashes.add(root.getData());
		corruptedPaths.add(corruptedHashes);
		recursive(root, corruptedHashes, corruptedPaths, correctHashes);
		return corruptedPaths;		
	}
	
	public void recursive(Node root, Stack<String> corrupted, ArrayList<Stack<String>> corruptedPaths, Set<String> meta) {
	
		if(root.getLeft() == null && root.getRight() == null) {
			return;
		}else if(root.getLeft() != null && root.getRight() == null) {
			corrupted.push(root.getLeft().getData());
			recursive(root.getLeft(),corrupted,corruptedPaths,meta);
		}else {
			if(!meta.contains(root.getLeft().getData()) && meta.contains(root.getRight().getData())) {
				corrupted.push(root.getLeft().getData());
				recursive(root.getLeft(),corrupted,corruptedPaths,meta);
			}else if(meta.contains(root.getLeft().getData()) && !meta.contains(root.getRight().getData())) {
				corrupted.push(root.getRight().getData());
				recursive(root.getRight(),corrupted,corruptedPaths,meta);
			}else {
				Stack<String> newCorrupted = new Stack<String>();
				newCorrupted.addAll(corrupted);
				corrupted.add(root.getLeft().getData());
				newCorrupted.add(root.getRight().getData());
				corruptedPaths.add(newCorrupted);
				recursive(root.getLeft(),corrupted,corruptedPaths,meta);
				recursive(root.getRight(),newCorrupted,corruptedPaths,meta);
			}
		}
	}
}
