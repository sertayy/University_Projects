package project;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import util.HashGeneration;

public class Node {
    
    private File file;
    private String hash;
    private Node left;
    private Node right;
    
    public Node (File file) throws NoSuchAlgorithmException, IOException {
     this.file = file;
     left = null;
     right = null;
     hash = HashGeneration.generateSHA256(file);
    }
    
    public Node(Node left, Node right) throws NoSuchAlgorithmException, UnsupportedEncodingException {
    	this.left = left;
    	this.right = right;
    file = null;
    	
    		if(right == null && left == null) {
    			hash = ""; 
    		} else {
    			if(left == null) {
    				hash = HashGeneration.generateSHA256(right.hash);
    			} else if (right == null) {
    				hash = HashGeneration.generateSHA256(left.hash);
    			} else {
    				hash = HashGeneration.generateSHA256(left.hash + right.hash);
    			}
    		}
    }
    
    public Node getLeft() {
    		return left;
    }

    public Node getRight() {
		return right;
	}

	public String getData() {
		return hash;
	}
}
