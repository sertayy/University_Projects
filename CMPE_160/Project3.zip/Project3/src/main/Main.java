package main;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

import project.MerkleTree;

public class Main {

	public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
		
		
		MerkleTree m0 = new MerkleTree("data/2.txt");		
		String hash = m0.getRoot().getData();
		System.out.println(hash);
		
		boolean valid = m0.checkAuthenticity("data/2meta.txt");
		System.out.println(valid);
		// The following just is an example for you to see the usage. 
		// Although there is none in reality, assume that there are two corrupt chunks in this example.
		ArrayList<Stack<String>> corrupts = m0.findCorruptChunks("data/2meta.txt");
		System.out.println("Corrupt hash of first corrupt chunk is: " + corrupts.get(0).pop());
		System.out.println("Corrupt hash of second corrupt chunk is: " + corrupts.get(1).pop());
		
		download("secondaryPart/data/download_from_trusted.txt");
		
	}
	
	
	
	public static void download(String path) throws NoSuchAlgorithmException, IOException {
		// Entry point for the secondary part
// I used this link below to achieve downloading
// https://stackoverflow.com/questions/20265740/how-to-download-a-pdf-from-a-given-url-in-java
// The following code which I copied from the link, seems useful to me.
// URL url = new URL("https://upload.wikimedia.org/wikipedia/en/8/87/Example.JPG");
// InputStream in = url.openStream();
// Files.copy(in, Paths.get("someFile.jpg"), StandardCopyOption.REPLACE_EXISTING);
// in.close();
		
		File file = new File(path);
		Scanner sc2= new Scanner(file);
		int count=0;
		ArrayList<String> splitdata = new ArrayList<>();
		while(sc2.hasNext()) {
			count++;
			splitdata.add(sc2.next());
		}
		
		sc2.close();
		Scanner sc = new Scanner(file);
		URL url;
		InputStream in;
		File split = new File("secondaryPart/data/split");
		split.mkdir();
		ArrayList<String> insideSplit= new ArrayList<String>();
		
		for(int i=0; i<count/3; i++) {
			String link = sc.next();
			insideSplit.add(link);
			link=sc.next();
			sc.next();
			split = new File("secondaryPart/data/split/"+ (link.substring(link.lastIndexOf("/")+1,link.lastIndexOf("."))));
			split.mkdir();
		}
		sc.close();
		
		String urls;
		for(int i=0; i<count;i+=3) {
			urls=splitdata.get(i);
			url = new URL(urls);
			in = url.openStream();
			Files.copy(in, Paths.get("secondaryPart/data/"+(urls.substring(urls.lastIndexOf("/")+1,urls.lastIndexOf(".")))+".txt"), StandardCopyOption.REPLACE_EXISTING);
			urls=splitdata.get(i+1);
			url = new URL(urls);
			in = url.openStream();
			Files.copy(in, Paths.get("secondaryPart/data/"+(urls.substring(urls.lastIndexOf("/")+1,urls.lastIndexOf(".")))+".txt"), StandardCopyOption.REPLACE_EXISTING);
			urls= splitdata.get(i+2);
			url = new URL(urls);
			in = url.openStream();
			Files.copy(in, Paths.get("secondaryPart/data/"+(urls.substring(urls.lastIndexOf("/")+1,urls.lastIndexOf(".")))+".txt"), StandardCopyOption.REPLACE_EXISTING);
		}
	}
}


